def algorithmA(S, x):

    for i in range(len(S)):

        if S[i] == x: #if match is found

            return True

        else: #if match not found

            return False
